# get_papers/pubmed_client.py

from typing import List, Dict
from Bio import Entrez, Medline
import time

Entrez.email = "nampallyrakshitha@gmail.com"  # Replace with your actual email

def fetch_pubmed_ids(query: str, max_results: int = 20) -> List[str]:
    handle = Entrez.esearch(db="pubmed", term=query, retmax=max_results)
    record = Entrez.read(handle)
    return record["IdList"]

def fetch_details(pubmed_ids: List[str]) -> List[Dict]:
    handle = Entrez.efetch(db="pubmed", id=",".join(pubmed_ids), rettype="medline", retmode="text")
    records = Medline.parse(handle)
    parsed_records = []
    for record in records:
        parsed_records.append(record)
        time.sleep(0.3)
    return parsed_records
