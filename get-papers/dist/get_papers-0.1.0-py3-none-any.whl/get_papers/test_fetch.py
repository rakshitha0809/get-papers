from get_papers.pubmed_client import fetch_pubmed_ids, fetch_details
from get_papers.paper_filter import filter_non_academic
from get_papers.csv_writer import write_csv

query = "cancer immunotherapy"
ids = fetch_pubmed_ids(query)
papers = fetch_details(ids)

output_data = []

for paper in papers:
    title = paper.get("TI", "N/A")
    pmid = paper.get("PMID", "N/A")
    date = paper.get("DP", "N/A")
    email = paper.get("EM", "N/A")
    authors = paper.get("AU", [])
    affiliations = paper.get("AD", [])

    if isinstance(affiliations, str):
        affiliations = [affiliations] * len(authors)

    non_acads, companies = filter_non_academic(authors, affiliations)

    if non_acads:  # Only keep papers with non-academic authors
        output_data.append({
            "PubmedID": pmid,
            "Title": title,
            "Publication Date": date,
            "Non-academic Author(s)": "; ".join(non_acads),
            "Company Affiliation(s)": "; ".join(companies),
            "Corresponding Author Email": email
        })

write_csv(output_data, "papers_output.csv")  # or None for console output
